--
-- PostgreSQL database dump
--

\restrict ZPcVJpXwS6zev3CBI0tgfBwfRQYNCMaN0HPjlaN6XLX3unlAevgVke7A4Jm23k2

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    pengguna_id integer,
    aksi character varying(50) NOT NULL,
    tabel_target character varying(50),
    record_id integer,
    detail jsonb,
    ip_address inet,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: data_dampak_bencana; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_dampak_bencana (
    id integer NOT NULL,
    kejadian_id integer,
    wilayah_id integer NOT NULL,
    korban_meninggal integer DEFAULT 0,
    korban_hilang integer DEFAULT 0,
    korban_luka integer DEFAULT 0,
    jumlah_pengungsi integer DEFAULT 0,
    kerugian_rp numeric(18,2) DEFAULT '0'::numeric,
    rumah_rusak_berat integer DEFAULT 0,
    rumah_rusak_sedang integer DEFAULT 0,
    rumah_rusak_ringan integer DEFAULT 0,
    fasilitas_umum_rusak integer DEFAULT 0,
    fasilitas_kesehatan_rusak integer DEFAULT 0,
    sekolah_rusak integer DEFAULT 0,
    penduduk_terdampak integer DEFAULT 0,
    catatan text,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.data_dampak_bencana OWNER TO postgres;

--
-- Name: data_dampak_bencana_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.data_dampak_bencana_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.data_dampak_bencana_id_seq OWNER TO postgres;

--
-- Name: data_dampak_bencana_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.data_dampak_bencana_id_seq OWNED BY public.data_dampak_bencana.id;


--
-- Name: gempa_bmkg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gempa_bmkg (
    id integer NOT NULL,
    external_id character varying(50),
    magnitude numeric(3,1),
    kedalaman_km numeric(6,2),
    lokasi public.geometry(Point,4326),
    wilayah_teks character varying(200),
    waktu_kejadian timestamp with time zone,
    potensi_tsunami boolean DEFAULT false,
    dirasakan boolean DEFAULT false,
    synced_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.gempa_bmkg OWNER TO postgres;

--
-- Name: gempa_bmkg_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gempa_bmkg_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gempa_bmkg_id_seq OWNER TO postgres;

--
-- Name: gempa_bmkg_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gempa_bmkg_id_seq OWNED BY public.gempa_bmkg.id;


--
-- Name: jalan_terputus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jalan_terputus (
    id integer NOT NULL,
    geom public.geometry(LineString,4326) NOT NULL,
    alasan character varying(30),
    deskripsi text,
    status character varying(20) DEFAULT 'aktif'::character varying,
    dilaporkan_oleh integer,
    tanggal_lapor timestamp with time zone DEFAULT now(),
    tanggal_pulih timestamp with time zone,
    CONSTRAINT check_jalan_alasan CHECK (((alasan)::text = ANY ((ARRAY['longsor'::character varying, 'banjir'::character varying, 'jembatan_putus'::character varying, 'kerusakan_jalan'::character varying, 'lainnya'::character varying])::text[]))),
    CONSTRAINT check_jalan_status CHECK (((status)::text = ANY ((ARRAY['aktif'::character varying, 'sebagian'::character varying, 'pulih'::character varying])::text[])))
);


ALTER TABLE public.jalan_terputus OWNER TO postgres;

--
-- Name: jalan_terputus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jalan_terputus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jalan_terputus_id_seq OWNER TO postgres;

--
-- Name: jalan_terputus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jalan_terputus_id_seq OWNED BY public.jalan_terputus.id;


--
-- Name: kejadian_bencana; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kejadian_bencana (
    id integer NOT NULL,
    jenis_bencana character varying(30) NOT NULL,
    tanggal_kejadian timestamp with time zone NOT NULL,
    wilayah_id integer,
    lokasi public.geometry(Point,4326),
    deskripsi text,
    sumber_data character varying(50) DEFAULT 'operator_bpbd'::character varying,
    status_verifikasi character varying(20) DEFAULT 'terverifikasi'::character varying,
    dibuat_oleh integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT check_jenis_bencana CHECK (((jenis_bencana)::text = ANY ((ARRAY['gempa'::character varying, 'tsunami'::character varying, 'banjir'::character varying, 'longsor'::character varying, 'erupsi'::character varying, 'angin_puting_beliung'::character varying, 'kebakaran'::character varying, 'lainnya'::character varying])::text[]))),
    CONSTRAINT check_status_verifikasi CHECK (((status_verifikasi)::text = ANY ((ARRAY['terverifikasi'::character varying, 'menunggu'::character varying, 'ditolak'::character varying])::text[])))
);


ALTER TABLE public.kejadian_bencana OWNER TO postgres;

--
-- Name: kejadian_bencana_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kejadian_bencana_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.kejadian_bencana_id_seq OWNER TO postgres;

--
-- Name: kejadian_bencana_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kejadian_bencana_id_seq OWNED BY public.kejadian_bencana.id;


--
-- Name: wilayah_administratif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wilayah_administratif (
    id integer NOT NULL,
    kode_wilayah character varying(20) NOT NULL,
    nama character varying(150) NOT NULL,
    level character varying(20) NOT NULL,
    parent_id integer,
    populasi integer,
    geom public.geometry(MultiPolygon,4326) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    geom_simplified public.geometry(MultiPolygon,4326),
    CONSTRAINT check_wilayah_level CHECK (((level)::text = ANY ((ARRAY['provinsi'::character varying, 'kabupaten'::character varying, 'kecamatan'::character varying, 'nagari'::character varying])::text[])))
);


ALTER TABLE public.wilayah_administratif OWNER TO postgres;

--
-- Name: mv_dampak_per_kecamatan; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.mv_dampak_per_kecamatan AS
 SELECT w.id AS wilayah_id,
    w.nama,
    COALESCE(sum(d.kerugian_rp), (0)::numeric) AS total_kerugian,
    COALESCE(sum(d.korban_meninggal), (0)::bigint) AS total_meninggal,
    COALESCE(sum(d.korban_luka), (0)::bigint) AS total_luka,
    COALESCE(sum(d.penduduk_terdampak), (0)::bigint) AS total_terdampak,
    count(DISTINCT k.id) AS jumlah_kejadian,
    now() AS terakhir_refresh
   FROM ((public.wilayah_administratif w
     LEFT JOIN public.kejadian_bencana k ON ((k.wilayah_id = w.id)))
     LEFT JOIN public.data_dampak_bencana d ON ((d.kejadian_id = k.id)))
  WHERE ((w.level)::text = 'kecamatan'::text)
  GROUP BY w.id, w.nama
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_dampak_per_kecamatan OWNER TO postgres;

--
-- Name: pengguna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pengguna (
    id integer NOT NULL,
    nama character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    wilayah_tugas_id integer,
    aktif boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT check_pengguna_role CHECK (((role)::text = ANY ((ARRAY['operator'::character varying, 'admin'::character varying, 'pimpinan'::character varying])::text[])))
);


ALTER TABLE public.pengguna OWNER TO postgres;

--
-- Name: pengguna_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pengguna_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pengguna_id_seq OWNER TO postgres;

--
-- Name: pengguna_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pengguna_id_seq OWNED BY public.pengguna.id;


--
-- Name: posko_evakuasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posko_evakuasi (
    id integer NOT NULL,
    nama character varying(150) NOT NULL,
    jenis character varying(30),
    lokasi public.geometry(Point,4326) NOT NULL,
    kapasitas integer,
    fasilitas text[],
    kontak_pic character varying(100),
    kontak_telepon character varying(30),
    status character varying(20) DEFAULT 'aktif'::character varying,
    wilayah_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT check_posko_jenis CHECK (((jenis)::text = ANY ((ARRAY['posko_utama'::character varying, 'titik_kumpul'::character varying, 'shelter_sementara'::character varying, 'fasilitas_kesehatan'::character varying])::text[]))),
    CONSTRAINT check_posko_status CHECK (((status)::text = ANY ((ARRAY['aktif'::character varying, 'penuh'::character varying, 'nonaktif'::character varying])::text[])))
);


ALTER TABLE public.posko_evakuasi OWNER TO postgres;

--
-- Name: posko_evakuasi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posko_evakuasi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posko_evakuasi_id_seq OWNER TO postgres;

--
-- Name: posko_evakuasi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posko_evakuasi_id_seq OWNED BY public.posko_evakuasi.id;


--
-- Name: wilayah_administratif_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wilayah_administratif_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wilayah_administratif_id_seq OWNER TO postgres;

--
-- Name: wilayah_administratif_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wilayah_administratif_id_seq OWNED BY public.wilayah_administratif.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: data_dampak_bencana id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_dampak_bencana ALTER COLUMN id SET DEFAULT nextval('public.data_dampak_bencana_id_seq'::regclass);


--
-- Name: gempa_bmkg id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gempa_bmkg ALTER COLUMN id SET DEFAULT nextval('public.gempa_bmkg_id_seq'::regclass);


--
-- Name: jalan_terputus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jalan_terputus ALTER COLUMN id SET DEFAULT nextval('public.jalan_terputus_id_seq'::regclass);


--
-- Name: kejadian_bencana id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kejadian_bencana ALTER COLUMN id SET DEFAULT nextval('public.kejadian_bencana_id_seq'::regclass);


--
-- Name: pengguna id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pengguna ALTER COLUMN id SET DEFAULT nextval('public.pengguna_id_seq'::regclass);


--
-- Name: posko_evakuasi id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posko_evakuasi ALTER COLUMN id SET DEFAULT nextval('public.posko_evakuasi_id_seq'::regclass);


--
-- Name: wilayah_administratif id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wilayah_administratif ALTER COLUMN id SET DEFAULT nextval('public.wilayah_administratif_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
001_initial_schema
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, pengguna_id, aksi, tabel_target, record_id, detail, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: data_dampak_bencana; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_dampak_bencana (id, kejadian_id, wilayah_id, korban_meninggal, korban_hilang, korban_luka, jumlah_pengungsi, kerugian_rp, rumah_rusak_berat, rumah_rusak_sedang, rumah_rusak_ringan, fasilitas_umum_rusak, fasilitas_kesehatan_rusak, sekolah_rusak, penduduk_terdampak, catatan, updated_at) FROM stdin;
1	1	14	1	0	14	380	1850000000.00	18	42	115	3	1	2	1450	Tanggul penahan air sungai jebol sepanjang 25 meter.	2026-09-13 10:26:29.847427+07
2	2	12	3	1	8	45	2650000000.00	4	2	6	1	0	0	280	Akses jalan terputus selama 48 jam, material batu besar dan lumpur pekat.	2026-09-13 10:26:29.847427+07
3	3	16	0	0	5	520	950000000.00	2	19	84	2	0	1	2100	Evakuasi perahu karet BPBD dikerahkan ke perumahan Griya Anak Air.	2026-09-13 10:26:29.847427+07
4	4	8	0	0	2	85	420000000.00	0	8	34	1	0	0	750	Ketinggian air rob mencapai 40-70 cm di jalan raya.	2026-09-13 10:26:29.847427+07
5	5	6	0	0	7	120	780000000.00	3	14	28	2	1	1	620	Struktur bangunan tua colonial retak rambut hingga sedang.	2026-09-13 10:26:29.847427+07
6	6	21	4	0	19	650	3450000000.00	24	31	55	4	1	2	1890	Lahan pertanian sayur seluas 42 hektar tertimbun material vulkanik.	2026-09-13 10:26:29.847427+07
7	7	17	0	0	3	0	310000000.00	1	3	5	2	0	0	95	Kawasan wisata ditutup sementara selama 5 hari untuk stabilisasi tebing.	2026-09-13 10:26:29.847427+07
8	8	22	0	0	1	230	640000000.00	0	12	46	1	0	1	890	Jalan akses BIM sempat dialihkan melalui jalur alternatif.	2026-09-13 10:26:29.847427+07
9	9	13	0	0	4	60	190000000.00	2	9	22	1	0	0	180	Pohon tumbang menimpa jaringan kabel listrik PLN.	2026-09-13 10:26:29.847427+07
\.


--
-- Data for Name: gempa_bmkg; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gempa_bmkg (id, external_id, magnitude, kedalaman_km, lokasi, wilayah_teks, waktu_kejadian, potensi_tsunami, dirasakan, synced_at) FROM stdin;
1	13 Sep 2026_10:14:42 WIB	4.7	6.00	0101000020E6100000E17A14AE47615E409A999999999920C0	Pusat gempa berada di laut 48 km Timur laut Mbay, Nagekeo	2026-09-13 10:14:42+07	f	t	2026-09-13 12:03:37.172396+07
\.


--
-- Data for Name: jalan_terputus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jalan_terputus (id, geom, alasan, deskripsi, status, dilaporkan_oleh, tanggal_lapor, tanggal_pulih) FROM stdin;
1	0102000020E6100000020000001F85EB51B81659403D0AD7A3703DEEBFF4FDD478E9165940BE9F1A2FDD24EEBF	longsor	Material batu dan lumpur menutup jalan nasional	aktif	2	2026-09-13 11:01:55.54698+07	\N
2	0102000020E610000003000000F6285C8FC21D5940105839B4C876EEBF91ED7C3F351E5940643BDF4F8D97EEBF3BDF4F8D971E5940E3A59BC420B0EEBF	longsor	Uji coba pelaporan longsor tebing Sitinjau Lauik.	aktif	2	2026-09-13 11:40:16.651106+07	\N
3	0102000020E610000003000000F6285C8FC21D5940105839B4C876EEBF91ED7C3F351E5940643BDF4F8D97EEBF3BDF4F8D971E5940E3A59BC420B0EEBF	longsor	Uji coba pelaporan longsor tebing Sitinjau Lauik.	pulih	2	2026-09-13 11:46:05.855036+07	2026-09-13 11:46:05.883384+07
\.


--
-- Data for Name: kejadian_bencana; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kejadian_bencana (id, jenis_bencana, tanggal_kejadian, wilayah_id, lokasi, deskripsi, sumber_data, status_verifikasi, dibuat_oleh, created_at, updated_at) FROM stdin;
1	banjir	2025-11-15 01:30:00+07	14	0101000020E61000000AD7A3703D1A594052B81E85EB51ECBF	Banjir bandang luapan Batang Kuranji merendam ratusan pemukiman warga di Belimbing dan Gunung Sarik.	operator_bpbd	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
2	longsor	2025-12-02 11:15:00+07	12	0101000020E6100000F6285C8FC21D5940105839B4C876EEBF	Longsor tebing jalur utama Sitinjau Lauik menutup badan jalan nasional Padang-Solok dan menimpa 2 unit kendaraan.	operator_bpbd	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
3	banjir	2026-01-08 21:00:00+07	16	0101000020E6100000D7A3703D0A1759403D0AD7A3703DEABF	Luapan Sungai Batang Kandis akibat curah hujan ekstrem merendam kawasan perumahan di Lubuk Buaya.	operator_bpbd	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
4	banjir	2026-01-15 14:30:00+07	8	0101000020E61000004A0C022B87165940713D0AD7A370EDBF	Pasang air laut (rob) disertai hujan lebat menggenangi kawasan Purus dan Flamboyan Baru.	operator_bpbd	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
5	gempa	2026-02-04 04:12:00+07	6	0101000020E6100000D7A3703D0A175940E17A14AE47E1EEBF	Guncangan gempa tektonik M5.4 pantai barat Sumbar meretakkan sejumlah ruko dan pemukiman tua di Seberang Padang.	bmkg	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
6	erupsi	2026-02-18 23:45:00+07	21	0101000020E6100000AE47E17A141E5940333333333333D3BF	Lahar hujan Gunung Marapi membawa material pasir dan batu besar menerjang lahan pertanian dan jembatan nagari.	operator_bpbd	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
7	longsor	2026-03-01 17:20:00+07	17	0101000020E61000008FC2F5285C17594085EB51B81E85D3BF	Longsor dinding tebing Ngarai Sianok menimbun gazebo wisata dan jalan inspeksi taman panorama.	operator_bpbd	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
8	banjir	2026-03-11 06:15:00+07	22	0101000020E610000085EB51B81E1559405C8FC2F5285CE7BF	Sungai Batang Anai meluap merendam area persawahan dan akses lingkar luar Bandara Internasional Minangkabau.	operator_bpbd	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
9	angin_puting_beliung	2026-02-25 22:30:00+07	13	0101000020E6100000CDCCCCCCCC1C5940CDCCCCCCCCCCECBF	Angin puting beliung menerbangkan atap puluhan rumah di Limau Manis dan menumbangkan pohon pelindung.	operator_bpbd	terverifikasi	\N	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07
\.


--
-- Data for Name: pengguna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pengguna (id, nama, email, password_hash, role, wilayah_tugas_id, aktif, created_at) FROM stdin;
1	Administrator Pusdalops BPBD Sumbar	admin@sumbarprov.go.id	$2b$12$ZfH6jzCvd7YSbi0zO9hTBOdF1EJWtRkmq6WdANpdbJCf5dRuohDHm	admin	1	t	2026-09-13 10:58:58.118213+07
2	Operator Lapangan BPBD Kota Padang	operator.padang@sumbarprov.go.id	$2b$12$P7n5THjHIS22Sx2y5yqrSuKIcEysNkF/Zv.OY12km4B0527s2CsSG	operator	2	t	2026-09-13 10:58:58.118213+07
3	Kepala Pelaksana BPBD Sumbar	pimpinan@sumbarprov.go.id	$2b$12$CBngc4JBLX.EE3bGdUKkxup4jHx7iEwGStjBFuGy9nq1F.stcNQ2C	pimpinan	1	t	2026-09-13 10:58:58.118213+07
\.


--
-- Data for Name: posko_evakuasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posko_evakuasi (id, nama, jenis, lokasi, kapasitas, fasilitas, kontak_pic, kontak_telepon, status, wilayah_id, created_at, updated_at) FROM stdin;
2	TES (Tempat Evakuasi Sementara) Ulak Karang	shelter_sementara	0101000020E61000002063EE5A4216594062105839B4C8ECBF	1200	{air_bersih,genset,mck,pos_komunikasi,helipad_atap}	Rahmat Hidayat (Satgas Kelurahan Ulak Karang)	081374561234	aktif	2	2026-09-13 10:58:58.118213+07	2026-09-13 10:58:58.118213+07
3	Pusdalops PB BPBD Provinsi Sumatera Barat	posko_utama	0101000020E6100000DFE00B93A9165940C05B2041F163ECBF	800	{pusdalops,radio_komunikasi_hf_vhf,genset_cadangan,logistik_makanan,dapur_umum}	Pusdalops Sumbar Call Center	0751-7058835	aktif	1	2026-09-13 10:58:58.118213+07	2026-09-13 10:58:58.118213+07
4	Posko Logistik Balai Kota Padang Aie Pacah	posko_utama	0101000020E6100000151DC9E53F1859406688635DDC46EBBF	1800	{dapur_umum,helipad,logistik,air_bersih,tempat_tidur_lipat}	Irwan Suhardi (Bagian Umum Pemko)	085278904321	aktif	2	2026-09-13 10:58:58.118213+07	2026-09-13 10:58:58.118213+07
5	Faskes Darurat RSUP Dr. M. Djamil Padang	fasilitas_kesehatan	0101000020E6100000DD24068195175940AED85F764F1EEEBF	650	{igd_trauma_center,bank_darah,ambulans_lapangan,tenda_triage,helipad}	Dr. Fauzi Sp.B (Tim Penanggulangan Bencana RSUP)	0751-32372	aktif	2	2026-09-13 10:58:58.118213+07	2026-09-13 10:58:58.118213+07
6	Titik Kumpul Lapangan Rektorat Unand Limau Manis	titik_kumpul	0101000020E61000005A643BDF4F1D594048E17A14AE47EDBF	3500	{lapangan_terbuka_luas,auditorium_tertutup,air_bersih,masjid_kampus}	Biro Umum & Satpam Unand	08116601234	aktif	2	2026-09-13 10:58:58.118213+07	2026-09-13 10:58:58.118213+07
7	Posko Utama Lapangan Kantin Bukittinggi	posko_utama	0101000020E61000004850FC1873175940516B9A779CA2D3BF	1500	{dapur_umum,pos_kesehatan,tenda_peleton,air_bersih}	Zulkifli (BPBD Bukittinggi)	081363456789	aktif	3	2026-09-13 10:58:58.118213+07	2026-09-13 10:58:58.118213+07
8	TES Wisma Atlet Parit Malintang	shelter_sementara	0101000020E6100000CDCCCCCCCC0C5940B537F8C264AAE2BF	900	{tempat_tidur,mck_komplit,dapur_umum,posko_logistik}	BPBD Padang Pariaman	0751-91234	aktif	5	2026-09-13 10:58:58.118213+07	2026-09-13 10:58:58.118213+07
1	Posko Utama GOR H. Agus Salim	posko_utama	0101000020E6100000492EFF21FD165940780B24287E8CEDBF	250	{air_bersih,mck,dapur_umum,tenda_peleton,pos_kesehatan,genset}	Drs. Hendri (Kabid Kedaruratan BPBD Padang)	081267890123	aktif	2	2026-09-13 10:58:58.118213+07	2026-09-13 11:46:05.902037+07
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: wilayah_administratif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wilayah_administratif (id, kode_wilayah, nama, level, parent_id, populasi, geom, created_at, updated_at, geom_simplified) FROM stdin;
1	13	Provinsi Sumatera Barat	provinsi	\N	5534472	0106000020E610000001000000010300000001000000050000000000000000A05840CDCCCCCCCCCC0CC0CDCCCCCCCC7C5940CDCCCCCCCCCC0CC0CDCCCCCCCC7C5940000000000000F03F0000000000A05840000000000000F03F0000000000A05840CDCCCCCCCCCC0CC0	2026-09-13 10:04:10.962468+07	2026-09-13 10:04:10.962468+07	0106000020E610000001000000010300000001000000050000000000000000A05840CDCCCCCCCCCC0CC0CDCCCCCCCC7C5940CDCCCCCCCCCC0CC0CDCCCCCCCC7C5940000000000000F03F0000000000A05840000000000000F03F0000000000A05840CDCCCCCCCCCC0CC0
2	1371	Kota Padang	kabupaten	1	909040	0106000020E610000001000000010300000001000000050000003333333333135940CDCCCCCCCCCCF0BF3333333333235940CDCCCCCCCCCCF0BF33333333332359409A9999999999E9BF33333333331359409A9999999999E9BF3333333333135940CDCCCCCCCCCCF0BF	2026-09-13 10:04:10.971135+07	2026-09-13 10:04:10.971135+07	0106000020E610000001000000010300000001000000050000003333333333135940CDCCCCCCCCCCF0BF3333333333235940CDCCCCCCCCCCF0BF33333333332359409A9999999999E9BF33333333331359409A9999999999E9BF3333333333135940CDCCCCCCCCCCF0BF
3	1375	Kota Bukittinggi	kabupaten	1	121461	0106000020E61000000100000001030000000100000005000000F6285C8FC21559401F85EB51B81ED5BF9A999999991959401F85EB51B81ED5BF9A99999999195940EC51B81E85EBD1BFF6285C8FC2155940EC51B81E85EBD1BFF6285C8FC21559401F85EB51B81ED5BF	2026-09-13 10:04:10.972511+07	2026-09-13 10:04:10.972511+07	0106000020E61000000100000001030000000100000005000000F6285C8FC21559401F85EB51B81ED5BF9A999999991959401F85EB51B81ED5BF9A99999999195940EC51B81E85EBD1BFF6285C8FC2155940EC51B81E85EBD1BFF6285C8FC21559401F85EB51B81ED5BF
4	1306	Kabupaten Agam	kabupaten	1	529138	0106000020E610000001000000010300000001000000050000006666666666F65840CDCCCCCCCCCCDCBF6666666666165940CDCCCCCCCCCCDCBF6666666666165940333333333333C3BF6666666666F65840333333333333C3BF6666666666F65840CDCCCCCCCCCCDCBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E610000001000000010300000001000000050000006666666666F65840CDCCCCCCCCCCDCBF6666666666165940CDCCCCCCCCCCDCBF6666666666165940333333333333C3BF6666666666F65840333333333333C3BF6666666666F65840CDCCCCCCCCCCDCBF
5	1305	Kabupaten Padang Pariaman	kabupaten	1	430626	0106000020E6100000010000000103000000010000000500000033333333330359409A9999999999E9BF9A999999991959409A9999999999E9BF9A99999999195940CDCCCCCCCCCCDCBF3333333333035940CDCCCCCCCCCCDCBF33333333330359409A9999999999E9BF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E6100000010000000103000000010000000500000033333333330359409A9999999999E9BF9A999999991959409A9999999999E9BF9A99999999195940CDCCCCCCCCCCDCBF3333333333035940CDCCCCCCCCCCDCBF33333333330359409A9999999999E9BF
6	1371010	Padang Selatan	kecamatan	2	61460	0106000020E61000000100000001030000000100000005000000F6285C8FC215594085EB51B81E85EFBFB81E85EB5118594085EB51B81E85EFBFB81E85EB511859403D0AD7A3703DEEBFF6285C8FC21559403D0AD7A3703DEEBFF6285C8FC215594085EB51B81E85EFBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E61000000100000001030000000100000005000000F6285C8FC215594085EB51B81E85EFBFB81E85EB5118594085EB51B81E85EFBFB81E85EB511859403D0AD7A3703DEEBFF6285C8FC21559403D0AD7A3703DEEBFF6285C8FC215594085EB51B81E85EFBF
7	1371020	Padang Timur	kecamatan	2	78340	0106000020E610000001000000010300000001000000050000008FC2F5285C175940666666666666EEBFE17A14AE47195940666666666666EEBFE17A14AE4719594048E17A14AE47EDBF8FC2F5285C17594048E17A14AE47EDBF8FC2F5285C175940666666666666EEBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E610000001000000010300000001000000050000008FC2F5285C175940666666666666EEBFE17A14AE47195940666666666666EEBFE17A14AE4719594048E17A14AE47EDBF8FC2F5285C17594048E17A14AE47EDBF8FC2F5285C175940666666666666EEBF
8	1371030	Padang Barat	kecamatan	2	45210	0106000020E61000000100000001030000000100000005000000F6285C8FC21559403D0AD7A3703DEEBF8FC2F5285C1759403D0AD7A3703DEEBF8FC2F5285C175940A4703D0AD7A3ECBFF6285C8FC2155940A4703D0AD7A3ECBFF6285C8FC21559403D0AD7A3703DEEBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E61000000100000001030000000100000005000000F6285C8FC21559403D0AD7A3703DEEBF8FC2F5285C1759403D0AD7A3703DEEBF8FC2F5285C175940A4703D0AD7A3ECBFF6285C8FC2155940A4703D0AD7A3ECBFF6285C8FC21559403D0AD7A3703DEEBF
9	1371040	Padang Utara	kecamatan	2	68700	0106000020E61000000100000001030000000100000005000000F6285C8FC2155940A4703D0AD7A3ECBF48E17A14AE175940A4703D0AD7A3ECBF48E17A14AE1759405C8FC2F5285CEBBFF6285C8FC21559405C8FC2F5285CEBBFF6285C8FC2155940A4703D0AD7A3ECBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E61000000100000001030000000100000005000000F6285C8FC2155940A4703D0AD7A3ECBF48E17A14AE175940A4703D0AD7A3ECBF48E17A14AE1759405C8FC2F5285CEBBFF6285C8FC21559405C8FC2F5285CEBBFF6285C8FC2155940A4703D0AD7A3ECBF
10	1371050	Bungus Teluk Kabung	kecamatan	2	26800	0106000020E6100000010000000103000000010000000500000048E17A14AE175940CDCCCCCCCCCCF0BFAE47E17A141E5940CDCCCCCCCCCCF0BFAE47E17A141E594085EB51B81E85EFBF48E17A14AE17594085EB51B81E85EFBF48E17A14AE175940CDCCCCCCCCCCF0BF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E6100000010000000103000000010000000500000048E17A14AE175940CDCCCCCCCCCCF0BFAE47E17A141E5940CDCCCCCCCCCCF0BFAE47E17A141E594085EB51B81E85EFBF48E17A14AE17594085EB51B81E85EFBF48E17A14AE175940CDCCCCCCCCCCF0BF
11	1371060	Lubuk Begalung	kecamatan	2	120500	0106000020E61000000100000001030000000100000005000000000000000018594085EB51B81E85EFBF33333333331B594085EB51B81E85EFBF33333333331B5940C3F5285C8FC2EDBF0000000000185940C3F5285C8FC2EDBF000000000018594085EB51B81E85EFBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E61000000100000001030000000100000005000000000000000018594085EB51B81E85EFBF33333333331B594085EB51B81E85EFBF33333333331B5940C3F5285C8FC2EDBF0000000000185940C3F5285C8FC2EDBF000000000018594085EB51B81E85EFBF
12	1371070	Lubuk Kilangan	kecamatan	2	57400	0106000020E6100000010000000103000000010000000500000033333333331B594085EB51B81E85EFBF713D0AD7A320594085EB51B81E85EFBF713D0AD7A3205940713D0AD7A370EDBF33333333331B5940713D0AD7A370EDBF33333333331B594085EB51B81E85EFBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E6100000010000000103000000010000000500000033333333331B594085EB51B81E85EFBF713D0AD7A320594085EB51B81E85EFBF713D0AD7A3205940713D0AD7A370EDBF33333333331B5940713D0AD7A370EDBF33333333331B594085EB51B81E85EFBF
13	1371080	Pauh	kecamatan	2	63800	0106000020E610000001000000010300000001000000050000000AD7A3703D1A5940C3F5285C8FC2EDBF713D0AD7A3205940C3F5285C8FC2EDBF713D0AD7A3205940000000000000ECBF0AD7A3703D1A5940000000000000ECBF0AD7A3703D1A5940C3F5285C8FC2EDBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E610000001000000010300000001000000050000000AD7A3703D1A5940C3F5285C8FC2EDBF713D0AD7A3205940C3F5285C8FC2EDBF713D0AD7A3205940000000000000ECBF0AD7A3703D1A5940000000000000ECBF0AD7A3703D1A5940C3F5285C8FC2EDBF
14	1371090	Kuranji	kecamatan	2	142300	0106000020E61000000100000001030000000100000005000000B81E85EB5118594048E17A14AE47EDBF5C8FC2F5281C594048E17A14AE47EDBF5C8FC2F5281C59405C8FC2F5285CEBBFB81E85EB511859405C8FC2F5285CEBBFB81E85EB5118594048E17A14AE47EDBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E61000000100000001030000000100000005000000B81E85EB5118594048E17A14AE47EDBF5C8FC2F5281C594048E17A14AE47EDBF5C8FC2F5281C59405C8FC2F5285CEBBFB81E85EB511859405C8FC2F5285CEBBFB81E85EB5118594048E17A14AE47EDBF
15	1371100	Nanggalo	kecamatan	2	59700	0106000020E61000000100000001030000000100000005000000D7A3703D0A175940A4703D0AD7A3ECBFE17A14AE47195940A4703D0AD7A3ECBFE17A14AE47195940333333333333EBBFD7A3703D0A175940333333333333EBBFD7A3703D0A175940A4703D0AD7A3ECBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E61000000100000001030000000100000005000000D7A3703D0A175940A4703D0AD7A3ECBFE17A14AE47195940A4703D0AD7A3ECBFE17A14AE47195940333333333333EBBFD7A3703D0A175940333333333333EBBFD7A3703D0A175940A4703D0AD7A3ECBF
16	1371110	Koto Tangah	kecamatan	2	198500	0106000020E61000000100000001030000000100000005000000A4703D0AD71359405C8FC2F5285CEBBFEC51B81E851B59405C8FC2F5285CEBBFEC51B81E851B594048E17A14AE47E9BFA4703D0AD713594048E17A14AE47E9BFA4703D0AD71359405C8FC2F5285CEBBF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E61000000100000001030000000100000005000000A4703D0AD71359405C8FC2F5285CEBBFEC51B81E851B59405C8FC2F5285CEBBFEC51B81E851B594048E17A14AE47E9BFA4703D0AD713594048E17A14AE47E9BFA4703D0AD71359405C8FC2F5285CEBBF
17	1375010	Guguak Panjang	kecamatan	3	44200	0106000020E610000001000000010300000001000000050000001F85EB51B8165940295C8FC2F528D4BF713D0AD7A3185940295C8FC2F528D4BF713D0AD7A3185940E17A14AE47E1D2BF1F85EB51B8165940E17A14AE47E1D2BF1F85EB51B8165940295C8FC2F528D4BF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E610000001000000010300000001000000050000001F85EB51B8165940295C8FC2F528D4BF713D0AD7A3185940295C8FC2F528D4BF713D0AD7A3185940E17A14AE47E1D2BF1F85EB51B8165940E17A14AE47E1D2BF1F85EB51B8165940295C8FC2F528D4BF
18	1375020	Mandiangin Koto Selayan	kecamatan	3	52100	0106000020E610000001000000010300000001000000050000006666666666165940E17A14AE47E1D2BFE17A14AE47195940E17A14AE47E1D2BFE17A14AE471959409A9999999999D1BF66666666661659409A9999999999D1BF6666666666165940E17A14AE47E1D2BF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E610000001000000010300000001000000050000006666666666165940E17A14AE47E1D2BFE17A14AE47195940E17A14AE47E1D2BFE17A14AE471959409A9999999999D1BF66666666661659409A9999999999D1BF6666666666165940E17A14AE47E1D2BF
19	1375030	Aur Birugo Tigo Baleh	kecamatan	3	26900	0106000020E610000001000000010300000001000000050000001F85EB51B8165940713D0AD7A370D5BF295C8FC2F5185940713D0AD7A370D5BF295C8FC2F5185940295C8FC2F528D4BF1F85EB51B8165940295C8FC2F528D4BF1F85EB51B8165940713D0AD7A370D5BF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E610000001000000010300000001000000050000001F85EB51B8165940713D0AD7A370D5BF295C8FC2F5185940713D0AD7A370D5BF295C8FC2F5185940295C8FC2F528D4BF1F85EB51B8165940295C8FC2F528D4BF1F85EB51B8165940713D0AD7A370D5BF
20	1306010	Tanjung Raya	kecamatan	4	38100	0106000020E6100000010000000103000000010000000500000048E17A14AE075940666666666666D6BF0000000000105940666666666666D6BF00000000001059409A9999999999C9BF48E17A14AE0759409A9999999999C9BF48E17A14AE075940666666666666D6BF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E6100000010000000103000000010000000500000048E17A14AE075940666666666666D6BF0000000000105940666666666666D6BF00000000001059409A9999999999C9BF48E17A14AE0759409A9999999999C9BF48E17A14AE075940666666666666D6BF
21	1306080	Canduang	kecamatan	4	25400	0106000020E610000001000000010300000001000000050000007B14AE47E11A5940666666666666D6BFE17A14AE47215940666666666666D6BFE17A14AE47215940A4703D0AD7A3D0BF7B14AE47E11A5940A4703D0AD7A3D0BF7B14AE47E11A5940666666666666D6BF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E610000001000000010300000001000000050000007B14AE47E11A5940666666666666D6BFE17A14AE47215940666666666666D6BFE17A14AE47215940A4703D0AD7A3D0BF7B14AE47E11A5940A4703D0AD7A3D0BF7B14AE47E11A5940666666666666D6BF
22	1305010	Batang Anai	kecamatan	5	54200	0106000020E6100000010000000103000000010000000500000052B81E85EB11594048E17A14AE47E9BFB81E85EB5118594048E17A14AE47E9BFB81E85EB51185940C3F5285C8FC2E5BF52B81E85EB115940C3F5285C8FC2E5BF52B81E85EB11594048E17A14AE47E9BF	2026-09-13 10:26:29.847427+07	2026-09-13 10:26:29.847427+07	0106000020E6100000010000000103000000010000000500000052B81E85EB11594048E17A14AE47E9BFB81E85EB5118594048E17A14AE47E9BFB81E85EB51185940C3F5285C8FC2E5BF52B81E85EB115940C3F5285C8FC2E5BF52B81E85EB11594048E17A14AE47E9BF
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz, useslargeids) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: data_dampak_bencana_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.data_dampak_bencana_id_seq', 9, true);


--
-- Name: gempa_bmkg_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gempa_bmkg_id_seq', 47, true);


--
-- Name: jalan_terputus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jalan_terputus_id_seq', 3, true);


--
-- Name: kejadian_bencana_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kejadian_bencana_id_seq', 9, true);


--
-- Name: pengguna_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pengguna_id_seq', 3, true);


--
-- Name: posko_evakuasi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posko_evakuasi_id_seq', 8, true);


--
-- Name: wilayah_administratif_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wilayah_administratif_id_seq', 22, true);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: postgres
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: data_dampak_bencana data_dampak_bencana_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_dampak_bencana
    ADD CONSTRAINT data_dampak_bencana_pkey PRIMARY KEY (id);


--
-- Name: gempa_bmkg gempa_bmkg_external_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gempa_bmkg
    ADD CONSTRAINT gempa_bmkg_external_id_key UNIQUE (external_id);


--
-- Name: gempa_bmkg gempa_bmkg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gempa_bmkg
    ADD CONSTRAINT gempa_bmkg_pkey PRIMARY KEY (id);


--
-- Name: jalan_terputus jalan_terputus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jalan_terputus
    ADD CONSTRAINT jalan_terputus_pkey PRIMARY KEY (id);


--
-- Name: kejadian_bencana kejadian_bencana_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kejadian_bencana
    ADD CONSTRAINT kejadian_bencana_pkey PRIMARY KEY (id);


--
-- Name: pengguna pengguna_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pengguna
    ADD CONSTRAINT pengguna_email_key UNIQUE (email);


--
-- Name: pengguna pengguna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pengguna
    ADD CONSTRAINT pengguna_pkey PRIMARY KEY (id);


--
-- Name: posko_evakuasi posko_evakuasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posko_evakuasi
    ADD CONSTRAINT posko_evakuasi_pkey PRIMARY KEY (id);


--
-- Name: wilayah_administratif wilayah_administratif_kode_wilayah_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wilayah_administratif
    ADD CONSTRAINT wilayah_administratif_kode_wilayah_key UNIQUE (kode_wilayah);


--
-- Name: wilayah_administratif wilayah_administratif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wilayah_administratif
    ADD CONSTRAINT wilayah_administratif_pkey PRIMARY KEY (id);


--
-- Name: idx_dampak_kejadian; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dampak_kejadian ON public.data_dampak_bencana USING btree (kejadian_id);


--
-- Name: idx_dampak_wilayah; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dampak_wilayah ON public.data_dampak_bencana USING btree (wilayah_id);


--
-- Name: idx_gempa_lokasi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gempa_lokasi ON public.gempa_bmkg USING gist (lokasi);


--
-- Name: idx_gempa_waktu; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_gempa_waktu ON public.gempa_bmkg USING btree (waktu_kejadian DESC);


--
-- Name: idx_jalan_terputus_geom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jalan_terputus_geom ON public.jalan_terputus USING gist (geom);


--
-- Name: idx_jalan_terputus_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jalan_terputus_status ON public.jalan_terputus USING btree (status) WHERE ((status)::text = 'aktif'::text);


--
-- Name: idx_kejadian_jenis; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_kejadian_jenis ON public.kejadian_bencana USING btree (jenis_bencana);


--
-- Name: idx_kejadian_lokasi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_kejadian_lokasi ON public.kejadian_bencana USING gist (lokasi);


--
-- Name: idx_kejadian_tanggal; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_kejadian_tanggal ON public.kejadian_bencana USING btree (tanggal_kejadian DESC);


--
-- Name: idx_kejadian_wilayah; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_kejadian_wilayah ON public.kejadian_bencana USING btree (wilayah_id);


--
-- Name: idx_mv_dampak_wilayah_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_mv_dampak_wilayah_id ON public.mv_dampak_per_kecamatan USING btree (wilayah_id);


--
-- Name: idx_posko_lokasi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posko_lokasi ON public.posko_evakuasi USING gist (lokasi);


--
-- Name: idx_posko_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_posko_status ON public.posko_evakuasi USING btree (status);


--
-- Name: idx_wilayah_geom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wilayah_geom ON public.wilayah_administratif USING gist (geom);


--
-- Name: idx_wilayah_level; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wilayah_level ON public.wilayah_administratif USING btree (level);


--
-- Name: idx_wilayah_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_wilayah_parent ON public.wilayah_administratif USING btree (parent_id);


--
-- Name: audit_log audit_log_pengguna_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pengguna_id_fkey FOREIGN KEY (pengguna_id) REFERENCES public.pengguna(id);


--
-- Name: data_dampak_bencana data_dampak_bencana_kejadian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_dampak_bencana
    ADD CONSTRAINT data_dampak_bencana_kejadian_id_fkey FOREIGN KEY (kejadian_id) REFERENCES public.kejadian_bencana(id) ON DELETE CASCADE;


--
-- Name: data_dampak_bencana data_dampak_bencana_wilayah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_dampak_bencana
    ADD CONSTRAINT data_dampak_bencana_wilayah_id_fkey FOREIGN KEY (wilayah_id) REFERENCES public.wilayah_administratif(id);


--
-- Name: jalan_terputus jalan_terputus_dilaporkan_oleh_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jalan_terputus
    ADD CONSTRAINT jalan_terputus_dilaporkan_oleh_fkey FOREIGN KEY (dilaporkan_oleh) REFERENCES public.pengguna(id);


--
-- Name: kejadian_bencana kejadian_bencana_dibuat_oleh_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kejadian_bencana
    ADD CONSTRAINT kejadian_bencana_dibuat_oleh_fkey FOREIGN KEY (dibuat_oleh) REFERENCES public.pengguna(id);


--
-- Name: kejadian_bencana kejadian_bencana_wilayah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kejadian_bencana
    ADD CONSTRAINT kejadian_bencana_wilayah_id_fkey FOREIGN KEY (wilayah_id) REFERENCES public.wilayah_administratif(id);


--
-- Name: pengguna pengguna_wilayah_tugas_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pengguna
    ADD CONSTRAINT pengguna_wilayah_tugas_id_fkey FOREIGN KEY (wilayah_tugas_id) REFERENCES public.wilayah_administratif(id);


--
-- Name: posko_evakuasi posko_evakuasi_wilayah_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posko_evakuasi
    ADD CONSTRAINT posko_evakuasi_wilayah_id_fkey FOREIGN KEY (wilayah_id) REFERENCES public.wilayah_administratif(id);


--
-- Name: wilayah_administratif wilayah_administratif_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wilayah_administratif
    ADD CONSTRAINT wilayah_administratif_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.wilayah_administratif(id);


--
-- Name: mv_dampak_per_kecamatan; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.mv_dampak_per_kecamatan;


--
-- PostgreSQL database dump complete
--

\unrestrict ZPcVJpXwS6zev3CBI0tgfBwfRQYNCMaN0HPjlaN6XLX3unlAevgVke7A4Jm23k2

